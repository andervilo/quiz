package br.com.reactpost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactpostsApplicationTests {

	@Test
	void contextLoads() {
	}

}
