package br.com.reactpost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactpostsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactpostsApplication.class, args);
	}

}
