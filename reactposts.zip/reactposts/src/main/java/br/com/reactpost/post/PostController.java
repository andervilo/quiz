package br.com.reactpost.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/posts")
public class PostController {
	
	private PostRepository postRepository;

	@Autowired
	public PostController(PostRepository postRepository) {
		this.postRepository = postRepository;
	}
	
	@GetMapping
	public ResponseEntity<List<PostModel>> getPostList(){
		return ResponseEntity.ok(postRepository.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<PostModel> getPostById(@PathVariable Long id){
		return ResponseEntity.ok(postRepository.findById(id).get());
	}
	
	@PostMapping
	public ResponseEntity<PostModel> createPost(@RequestBody PostModel postModel){
		return ResponseEntity.ok(postRepository.saveAndFlush(postModel));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<PostModel> updatePost(@PathVariable Long id, @RequestBody PostModel postModel){
		PostModel postToUpdate = postRepository.findById(id).get();
		postToUpdate.setAuthor(postModel.getAuthor());
		postToUpdate.setBody(postModel.getBody());
		postToUpdate.setTitle(postModel.getTitle());
		return ResponseEntity.ok(postRepository.saveAndFlush(postToUpdate));
	}
	
	@DeleteMapping("/{id}")
	public void deletePost(@PathVariable Long id) {
		postRepository.deleteById(id);
	}

}
